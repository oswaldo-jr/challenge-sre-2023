#!/bin/bash
# Proposito: Filtro por nome de cliente 
# Autor: Oswaldo Galdino - og.junior@hotmail.com
# ------------------------------------------

  echo "content-type: text/html"
  echo
  echo
  echo "
  <html> <head> <title> Filtro 1 </title> </head>
  <body>
  "

  echo "<h2>Filtro por nome de cliente - Ex: cliente5 ou cliente10</h2>"
  if [ "$QUERY_STRING" ];then
        cliente="$(echo $QUERY_STRING | sed 's/\(.*=\)\(.*\)\(\&.*\)/\2/')"
        echo "<br>"
        echo "Pesquisando:<b>$cliente</b>"
        echo "<pre>"
        ls -lhtr /home/ubuntu/challenge-sre-2023 | grep -n $cliente
        echo "</pre>"
        echo "Fim."
  else
        echo "
        <form method=\"GET\" action=\"filtro1.cgi\">
        <b>Digite o nome do clientee pressione ENTER - Ex: cliente5 ou cliente10:</b>
        <input size=40 name=host value=\"\">
        <input type=hidden size=40 name=teste value=\"resultado\">
        </form>"
  fi

  echo "</body>"
  echo "</html>"
